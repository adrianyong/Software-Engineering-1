/**
 * Recipe gets the nutritional information from a recipe that the user can use
 * @author 100021268 100122248 100137721 100090034
 */
package model;

public class Recipe {
    
}
