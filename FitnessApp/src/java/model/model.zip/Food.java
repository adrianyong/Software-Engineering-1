/**
 * Food gets the nutritional information of the food from  a recipe
 * @author 100021268 100122248 100137721 100090034
 */
package model;

public class Food {
    double protein;
    double carbohydrates;
    double fat;
    double fibre;
    double sugar;
    double calories;
    double isVeg;
    
    void getProtein(){
        //returns double protein
    }
    
    void getCarbs(){
        //returns double protein
    }
    
    void getFat(){
        //returns double protein
    }
    
    void getSugars(){
        //returns double protein
    }
    
    void getCalories(){
        //returns double protein
    }
    
//    void getNutrients(){
//        //returns double protein
//    }
    
    void isVegetablesFruit(){
        //returns boolean fruitVeg
    }
    
//    @Override
//    void toString(){
//        //returns nutrients all as a string
//    }
    
    
}
